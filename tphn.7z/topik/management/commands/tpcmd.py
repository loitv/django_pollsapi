from django.core.management.base import BaseCommand, CommandError
from topik.models import Candidate
from topik.tests import create_new, test
from topik.services import get_imgidx, get_default_param, remove_unused_images


class Command(BaseCommand):
    def add_arguments(self, parser):
        parser.add_argument(
            'opt', nargs='+', type=str
        )

    def handle(self, *args, **options):
        if len(options['opt']) == 1:
            if 'test' in options['opt']:
                test()
            elif 'create' in options['opt']:
                create_new()
            elif 'upload' in options['opt']:
                get_imgidx()
            elif 'get_params' in options['opt']:
                get_default_param()
            elif 'remove_img' in options['opt']:
                remove_unused_images()
            self.stdout.write(self.style.SUCCESS('Successful'))
        else:
            raise CommandError('Error!')

