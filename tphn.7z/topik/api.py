from rest_framework.views import APIView
from rest_framework.parsers import MultiPartParser, FormParser
from rest_framework.response import Response
from rest_framework import status
from django.core.files.storage import FileSystemStorage
import datetime
import os
from django.utils import timezone
from django.conf import settings

from topik.models import Avatar


class FileView(APIView):
    parser_classes = (MultiPartParser, FormParser)

    @staticmethod
    def post(request, *args, **kwargs):

        try:
            now = timezone.now().strftime('%Y%m%d%H%M%S%f')
            file = request.data.get('avatar')
            file_path = os.path.join(settings.BASE_DIR, 'static', 'images', 'avatar', '{}_{}'
                                     .format(now, file.name))
            fs = FileSystemStorage()
            fs.save(file_path, file)
            avatar = Avatar(name='{}_{}'.format(now, file.name),
                            save_path='/static/images/avatar/{}_{}'.format(now, file.name))
            avatar.save()

            return Response({'status': 'ok', 'avatar_id': str(avatar.id), 'src': '/static/images/avatar/{}_{}'.format(now, file.name)}, status=status.HTTP_201_CREATED)
        except Exception as e:
            print(str(e))
            return Response({'status': 'false', 'msg': '{}'.format(str(e))}, status=status.HTTP_403_FORBIDDEN)


