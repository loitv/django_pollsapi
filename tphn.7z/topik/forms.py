from django import forms

from topik.models import Candidate


class CandidateForm(forms.ModelForm):

    class Meta:
        model = Candidate
        fields = ('a_level', 'u_email0', 'u_email1', 'u_pwd', 'u_pwd_confirm', 'u_surname', 'u_kname',
                  'u_birth0', 'u_birth1', 'u_birth2', 'u_age', 'u_sex', 'u_nation', 'u_sid', 'u_job', 'u_tel', 'u_hp',
                  'u_addr', 'u_motive', 'u_purpose',)
