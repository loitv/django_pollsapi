import requests
import re
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import Select, WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions
from topik.models import Candidate, Avatar
from topik.configs import tphn_config
from topik.serializer import CandidateSerializer
from bs4 import BeautifulSoup
import os
import json
from django.conf import settings


def form_submit(c_id):
    c = Candidate.objects.get(id=c_id)
    avatar = Avatar.objects.get(id=c.get('avatar_id'))
    if not avatar.imgidx:
        imgidx = get_imgidx()
        if imgidx:
            avatar.imgidx = imgidx
            avatar.save()
        else:
            return {'status': 'false', 'msg': 'Missing imgidx field'}
    c_data = CandidateSerializer(c).data
    c_data.pop('avatar_id', None)
    c_data['imgidx'] = avatar.imgidx
    r = requests.post('http://www.topikhanoi.com/bbs/apply_reg_update.php', data=c_data)
    print(r.headers)
    print(r.text)
    return {'status': 'ok', 'msg': 'ok'}


def get_imgidx():
    files = {'file': ('anh.jpg', open(os.path.join(settings.BASE_DIR, 'static', 'images', 'avatar', '478371a.jpg'), 'rb'))}
    response = requests.post(tphn_config.tphn['img_upload_endpoint'], headers=tphn_config.headers, files=files)
    print(response.text)
    result = json.loads(response.text)
    if result.get('rslt') == 'ok':
        return result.get('r_tmpidx')


def get_default_param(url=None):
    if not url:
        r = requests.get(tphn_config.tphn.get('url'))
        soup = BeautifulSoup(r.text, 'lxml')
        btn_register = soup.select_one(tphn_config.tphn.get('register_btn_css'))
        url = get_absolute_url(btn_register['href'])
    r = requests.get(url)
    print(url)
    soup = BeautifulSoup(r.text, 'lxml')
    hidden_inputs = soup.select("input[type=hidden]")
    for input_tag in hidden_inputs:
        d = {'name': input_tag['name'], 'value': input_tag['value']}
        print(d)

    # print(hidden_inputs)


def get_absolute_url(url):
    host = tphn_config.tphn.get('host')
    if url.startswith("http"):
        return url
    else:
        return '{host}{sub}'.format(host=host, sub=re.search('^(?:[^\w]+)?([\w].+)$', url).group(1))


def remove_unused_images():
    unused_avatar = Avatar.objects.exclude(id__in=Candidate.objects.values_list('avatar_id', flat=True))
    for a in unused_avatar:
        img_path = os.path.join(settings.BASE_DIR, *a.save_path.split('/'))
        if os.path.exists(img_path):
            os.remove(img_path)
        a.delete()



