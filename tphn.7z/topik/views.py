from django.shortcuts import render
from topik.models import *

from topik.forms import *

# Create your views here.


def registration(request):
    exam = Exam.objects.filter(status=1).values()[0]
    return render(request, 'topik/register.html', {'exam': exam})


def submit_form(request):
    request_data = request.POST
    print(request_data)
    candidate_form = CandidateForm(request_data)
    print(candidate_form.is_valid())
    if candidate_form.is_valid():
        current_exam = Exam.objects.get(status=1)
        if not Candidate.objects.filter(exam=current_exam, u_sid=request_data.get('u_sid')):
            candidate = candidate_form.save(commit=False)
            candidate.avatar = Avatar.objects.get(id=candidate_form.data.get('avatar_id'))
            candidate.exam = current_exam
            candidate.save()
    return render(request, 'base.html')


def upload_2(request):
    return render(request, 'topik/register_2.html')
