from django.db import models
from django import forms

# Create your models here.


class Avatar(models.Model):
    name = models.CharField(max_length=255)
    save_path = models.CharField(max_length=255)
    imgidx = models.CharField(max_length=255, default="")

    def __str__(self):
        return self.name


class Exam(models.Model):
    STATUS_CHOICES = (
        (0, 'Inactive'),
        (1, 'Active')
    )
    name = models.CharField(max_length=255)
    tk_idx = models.CharField(max_length=255, unique=True)
    status = models.SmallIntegerField(choices=STATUS_CHOICES, default=0)

    def __str__(self):
        return self.name


class Candidate(models.Model):
    SEX_CHOICES = (
        ('m', 'Male'),
        ('f', 'Female'),
    )
    a_uid = models.CharField(max_length=128, default="")
    w = models.CharField(max_length=128, default="")
    a_idx = models.CharField(max_length=128, default="")
    sca = models.CharField(max_length=128, default="")
    sfl = models.CharField(max_length=128, default="")
    stx = models.CharField(max_length=128, default="")
    page = models.CharField(max_length=128, default="")
    exam = models.ForeignKey(Exam, on_delete=models.CASCADE, null=True)
    a_status_old = models.CharField(max_length=128, default="")
    avatar = models.OneToOneField(Avatar, on_delete=models.CASCADE, primary_key=False)
    a_level = models.CharField(max_length=16)
    t_code = models.CharField(max_length=16, default="00")
    u_email0 = models.CharField(max_length=128)
    u_email1 = models.CharField(max_length=128)
    u_pwd = models.CharField(max_length=128)
    u_pwd_confirm = models.CharField(max_length=128)
    u_surname = models.CharField(max_length=128)
    u_kname = models.CharField(max_length=128)
    u_birth0 = models.CharField(max_length=128)
    u_birth1 = models.CharField(max_length=128)
    u_birth2 = models.CharField(max_length=128)
    u_age = models.CharField(max_length=128)
    u_sex = models.CharField("Giới tính", max_length=128, default="m", choices=SEX_CHOICES)
    u_nation = models.CharField(max_length=128, default="VNM")
    u_sid = models.CharField(max_length=128)
    u_job = models.CharField("Nghề nghiệp", max_length=128)
    u_job_etc = models.CharField(max_length=255, default="")
    u_tel = models.CharField(max_length=128, default="1236547890")
    u_hp = models.CharField(max_length=128, default="1234568790")
    u_addr = models.CharField(max_length=128, default="Ha Noi")
    u_motive = models.CharField(max_length=128, default="1")
    u_motive_etc = models.CharField(max_length=128, default="")
    u_purpose = models.CharField(max_length=128, default="1")
    u_purpose_etc = models.CharField(max_length=128, default="")
    checkbox = models.CharField(max_length=128, default="on")
    checkbox2 = models.CharField(max_length=128, default="on")

    class Meta:
        unique_together = ('exam', 'u_sid',)
