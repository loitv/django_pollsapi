from django.contrib import admin
from topik.models import *

# Register your models here.


@admin.register(Exam)
class ExamAdmin(admin.ModelAdmin):
    list_display = ('name', 'tk_idx', 'status')


@admin.register(Candidate)
class CandidateAdmin(admin.ModelAdmin):
    list_display = ('u_surname', 'u_sex', 'u_sid', 'exam', 'avatar', 'a_level', 'u_email0', 'u_email1', 'u_job',
                    'u_tel', 'u_addr', 'u_motive', 'u_purpose')
    search_fields = ('u_surname', 'u_sid', 'exam')
    list_filter = ('u_surname', 'u_sid', 'exam',)
    ordering = ('u_surname', 'u_sid', 'exam')
