from django.urls import path

from topik import views
from topik.api import FileView


urlpatterns = [
    path('', views.registration),
    path('submit', views.submit_form),
    path('upload_2', views.upload_2),
    path('upload', FileView.as_view(), name='file-upload'),
]
