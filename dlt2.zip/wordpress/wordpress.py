import os
import pickle
import requests
import json

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
wp_end_point = 'http://localhost:8002/wp-json'
token_end_point = 'http://localhost:8002/wp-json/jwt-auth/v1/token'


def get_token_str():
    token_file = os.path.join(BASE_DIR, 'wp_token.pkl')
    if os.path.exists(token_file):
        with open(token_file, 'rb') as f:
            return pickle.load(f)
    else:
        return generate_new_token()


def generate_new_token():
    params = {
        "username": 'newsky1763',
        "password": 'klCF4693@'
    }
    r = requests.post(token_end_point,
                      headers={"Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"}, data=params)
    if r.status_code == 200:
        response = json.loads(r.text)
        token_file = os.path.join(BASE_DIR, 'wp_token.pkl')
        with open(token_file, 'wb') as f:
            pickle.dump(response.get("token"), f)
        return response.get("token")
    return ""


def get_headers():
    return {"Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
           "Authorization": "Bearer {}".format(get_token_str())}


def get_posts():
    posts_url = '{}/wp/v2/posts'.format(wp_end_point)
    r = requests.get(posts_url, headers=get_headers())
    response = json.loads(r.text)
    for p in response:
        for key, value in p.items():
            if value:
                print('\t{:<20}{:<30}'.format(key, str(value)))


def get_post_by_id(post_id):
    post_url = '{}/wp/v2/posts/{}'.format(wp_end_point, post_id)
    r = requests.get(post_url, headers=get_headers())
    if r.status_code == 200:
        response = json.loads(r.text)
        return response
    return None


def create_post():
    pass


def get_tags():
    tags_url = '{}/wp/v2/tags'.format(wp_end_point)
    r = requests.get(tags_url, headers=get_headers())
    if r.status_code == 200:
        response = json.loads(r.text)
        for p in response:
            for key, value in p.items():
                if value:
                    print('\t{:<20}{:<30}'.format(key, str(value)))
    else:
        print(json.loads(r.text))


def get_tag_by_id(tag_id):
    tag_url = '{}/wp/v2/tags/{}'.format(wp_end_point, tag_id)
    r = requests.get(tag_url, headers=get_headers())
    if r.status_code == 200:
        response = json.loads(r.text)
        return response
    return None


def get_pages():
    pages_url = '{}/wp/v2/pages'.format(wp_end_point)
    r = requests.get(pages_url, headers=get_headers())
    if r.status_code == 200:
        response = json.loads(r.text)
        for p in response:
            for key, value in p.items():
                if value:
                    print('\t{:<20}{:<30}'.format(key, str(value)))


def get_page_by_id(page_id):
    page_url = '{}/wp/v2/pages/{}'.format(wp_end_point, page_id)
    r = requests.get(page_url, headers=get_headers())
    if r.status_code == 200:
        response = json.loads(r.text)
        return response
    return None


def get_media():
    media_url = '{}/wp/v2/media'.format(wp_end_point)
    r = requests.get(media_url, headers=get_headers())
    if r.status_code == 200:
        response = json.loads(r.text)
        for p in response:
            for key, value in p.items():
                if value:
                    print('\t{:<20}{:<30}'.format(key, str(value)))


def get_media_by_id(media_id):
    media_url = '{}/wp/v2/media/{}'.format(wp_end_point, media_id)
    r = requests.get(media_url, headers=get_headers())
    if r.status_code == 200:
        response = json.loads(r.text)
        return response
    return None


# print(get_tags())

get_pages()
