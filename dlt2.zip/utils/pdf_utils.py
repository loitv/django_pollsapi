import time
import os
from PyPDF2 import PdfFileReader, PdfFileWriter

max_size = 20000000

f_path = "[Jennifer_Niederst_Robbins]_Learning_Web_Design-_A(z-lib.org).pdf"
f_size = os.path.getsize(f_path)
num_parts = f_size // max_size if (f_size / max_size) == (f_size // max_size) else f_size // max_size + 1
print(num_parts)

def split_pdf_by_range(prefix, start, end):
    start = 1 if start < 1 else start
    pdf_reader = PdfFileReader(open(f_path, "rb"))
    pdf_writer1 = PdfFileWriter()
    for page in range(start - 1, end):
        pdf_writer1.addPage(pdf_reader.getPage(page))
    with open("{}_{}_{}.pdf".format(prefix, start, end), 'wb') as file1:
        pdf_writer1.write(file1)


def split_for_git_upload():
    pdf_file = open(f_path, "rb")
    input_pdf = PdfFileReader(pdf_file)
    num_pages = input_pdf.numPages
    pages_x_part = num_pages // num_parts if (num_pages // num_parts) == (
                num_pages // num_parts) else num_pages // num_parts + 1
    print(pages_x_part)
    for i in range(num_parts + 1):
        page_start = pages_x_part * i
        page_end = pages_x_part * (i + 1) if pages_x_part * (i + 1) < num_pages else num_pages
        print('Start: {}\tEnd: {}'.format(page_start, page_end))
        start_time = time.time()
        split_pdf_by_range('Learning_Web_Design', page_start, page_end)
        print('Times: {}s'.format(time.time() - start_time))
        break

split_for_git_upload()


# with open('[Jennifer_Niederst_Robbins]_Learning_Web_Design-_A(z-lib.org).pdf', "rb") as pdf_file:
#     input_pdf = PdfFileReader(pdf_file)
#     num_pages = input_pdf.numPages
#     pages_x_part = num_pages // num_parts if (num_pages // num_parts) == (num_pages // num_parts) else num_pages // num_parts + 1
#     print(pages_x_part)
#     for i in range(num_parts + 1):
#         page_start = pages_x_part * i + 1
#         page_end = pages_x_part * (i + 1) if pages_x_part * (i + 1) < num_pages else num_pages
#         print('Start: {}\tEnd: {}'.format(page_start, page_end))
#         for j in range(page_start, page_end):
#             # print(j)
#             output = PdfFileWriter()
#             # output.insertPage(input_pdf.getPage(j))
#             output.appendPagesFromReader(input_pdf.getPage(j))
#             # output.addPage(input_pdf.getPage(j))
#         with open("document_page_{}_{}.pdf".format(page_start, page_end), "wb") as outputStream:
#             output.write(outputStream)
#         break
