from django.urls import path, include
from .views import *
from .api import XApi, XViewSet

nrop_list = XViewSet.as_view({'get': 'list_nrops'})
update_star = XViewSet.as_view({'post': 'update_star'})
add_star = XViewSet.as_view({'post': 'add_star'})


urlpatterns = [
    path('', x_index, name='x-index'),
    path('2/', x_index_2, name='x-index-2'),
    path('stars/', stars_index, name='star_list'),
    path('test/', test, name='test'),
    path('api/test/', XApi.as_view(), name='test-view'),
    path('api/nrops/', nrop_list),
    path('api/star/update', update_star),
    path('api/star/add', add_star),
]
