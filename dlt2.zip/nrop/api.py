from django.http import HttpResponse
from django.views import View
from django.shortcuts import get_object_or_404
from rest_framework import viewsets
from rest_framework.response import Response
from .x_serializer import NropSerializer
from rest_framework.renderers import JSONRenderer
from datetime import datetime
from django.utils import timezone
from .models import *
from nrop.services.crawl_nrop import crawl_by_search_star_name, add_new_star


class XApi(View):
    def get(self, request, *args, **kwargs):

        return HttpResponse('Hello, World!')


class XViewSet(viewsets.ViewSet):
    def list_nrops(self, request):
        nrops = Nrop.objects.all()[:10]
        nrop_serializer = NropSerializer(nrops, many=True)
        return Response(nrop_serializer.data)

    def update_star(self, request):
        star_id = request.POST.get('star_id')
        try:
            # pass
            star = get_object_or_404(Star, id=star_id)
            web_config = WebConfig.objects.all()[0]
            new_records = crawl_by_search_star_name(web_config, star, True, True, 0)
            star.last_update = timezone.now()
            star.save()
            return Response({'status': 'ok', 'message': 'Found {} new records'.format(new_records)})
        except Exception as e:
            print(str(e))
            return Response({'status': 'false', 'message': 'Something error'})

    def add_star(self, request):
        star_name = request.POST.get('star_name')
        print(star_name)
        try:
            star = add_new_star(star_name)
            if star:
                star.last_update = timezone.now()
                star.save()
                return Response({'status': 'ok', 'message': 'Ok'})
            else:
                return Response({'status': 'exist', 'message': 'Exist'})
        except Exception as e:
            print(str(e))
            return Response({'status': 'false', 'message': 'Something error'})

