from django.shortcuts import render, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.db.models import Q, Count
from .models import *
import time

# Create your views here.


@login_required(login_url='/accounts/login/')
def x_index(request):
    start_time = time.time()
    f = Q()
    f2 = Q()

    star_id = request.GET.get('star_id')
    if star_id and star_id != "0":
        f = f & Q(stars__id=star_id)
        f2 = f2 & Q(nrop__stars__id=star_id)
    else:
        star_id = "0"

    studio_id = request.GET.get('studio_id')
    if studio_id and studio_id != "0":
        f = f & Q(studio__id=studio_id)
        f2 = f2 & Q(nrop__studio__id=studio_id)
    else:
        studio_id = "0"

    cat_id = request.GET.get('cat_id')
    if cat_id and cat_id != "0":
        f = f & Q(categories__id=cat_id)
        f2 = f2 & Q(nrop__categories__id=cat_id)
    else:
        cat_id = "0"

    year = request.GET.get('year')
    if year and year != "0":
        f = f & Q(release_date__year=year)
        f2 = f2 & Q(nrop__release_date__year=year)
    else:
        year = "0"
    nrops = Nrop.objects.filter(f)

    filters = {'star_id': star_id, 'studio_id': studio_id, 'cat_id': cat_id, 'year': year}

    # get all stars
    stars = Star.objects.annotate(count=Count('nrop', filter=f2)).only('name').order_by('name')
    star_list = list({'id': s.id, 'name': s.name, 'count': s.count} for s in stars)

    # get all studio
    studios = Studio.objects.annotate(count=Count('nrop', filter=f2)).only('name').order_by('-count')
    studio_list = list({'id': s.id, 'name': s.name, 'count': s.count} for s in studios)

    # get all years
    years = nrops.values('release_date__year').order_by('release_date__year').annotate(total=Count('id'))
    year_list = list({'value': d.get('release_date__year'), 'count': d.get('total')} for d in years)

    # get all categories
    cats = Category.objects.annotate(count=Count('nrop', filter=f2)).only('name')
    cat_list = list({'id': c.id, 'name': c.name, 'count': c.count} for c in cats)

    paginator = Paginator(nrops, 18)  # 18 records in each page
    page = request.GET.get('page')
    try:
        nrops = paginator.page(page)
    except PageNotAnInteger:
        nrops = paginator.page(1)
    except EmptyPage:
        nrops = paginator.page(paginator.num_pages)

    print('Load time: {}'.format(time.time() - start_time))
    print(nrops[0].categories.values())

    for n in nrops:
        # n.cover_path = '/static/images/x/cover/default.jpg'
        if n.cover_path and n.cover_path.startswith('ok:'):
            n.cover_path = n.cover_path[3:]
        else:
            n.cover_path = '/static/images/x/cover/default.jpg'

    return render(request, 'x/index.html',
                  {'stars': star_list,
                   'studios': studio_list,
                   'years': year_list,
                   'cats': cat_list,
                   'page': page,
                   'nrops': nrops,
                   'filters': filters})


def x_index_2(request):
    nrops = Nrop.objects.all().only('url', 'title', 'cover_path')[:40]
    default_img_path = '/static/images/x/cover/default.jpg'
    nrop_list = list({'url': x.url, 'title': x.title, 'cover_path': x.cover_path[3:]} if
                     (x.cover_path and x.cover_path.startswith('ok:'))
                     else {'url': x.url, 'title': x.title, 'cover_path': default_img_path} for x in nrops)

    return render(request, 'x/stars.html', {'nrops': nrop_list})


def stars_index(request):
    stars = Star.objects.annotate(count=Count('nrop')).order_by('name').values()
    star_list = list(stars)

    return render(request, 'x/stars.html', {'stars': star_list})


def test(request):
    return render(request, 'test.html')


def get_time_str(update_time):
    return update_time.strftime('%Y-%m-%d %H:%M:%S')
