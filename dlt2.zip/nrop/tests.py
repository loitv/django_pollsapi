from django.test import TestCase
import re
import requests
from bs4 import BeautifulSoup
from datetime import datetime
from django.template.defaultfilters import slugify
from nrop.models import *
from nrop.services.crawl_nrop import safe_get, safe_get_link_content, check_star_name_in_title

# Create your tests here.


def test_1(s):
    names = [s.name]
    if s.other_name:
        names.extend(s.other_name.split(','))
    xs = s.nrop.only('title', 'url')
    for x in xs:
        r = re.search(r'^(?:.+[^a-zA-Z0-9])?(' + '|'.join(names) + r')(?:[^a-zA-Z0-9].+)?$', x.title, re.IGNORECASE)
        if r:
            pass
            # print(r.group(1))
        else:
            print('{} - {} - {}'.format(s.name, x.title, x.url))
            x.delete()


def test_2():
    ss = Star.objects.all()
    for s in ss:
        test_1(s)


def test(case):
    web_config = WebConfig.objects.all()[0]
    if case == 1:
        url = 'https://www.hotpornfile.org/eternaldesire-com-19-12-26-kay-j-cozy-xxx-imageset-gagball/594858'
        soup = BeautifulSoup(requests.get(url).text, 'lxml')
        title = safe_get(soup, web_config.title_css)
        upload_at = safe_get(soup, web_config.upload_at_css)
        if upload_at:
            upload_at = datetime.strptime(upload_at, '%B %d, %Y')
        categories = list(cat.get_text() for cat in soup.select(web_config.category_css))
        # cover_url = soup.select(web_config.cover_url_css)[0]['href']
        cover_url = safe_get_link_content(soup, web_config.cover_url_css)
        css = 'div.entry-content div.hpf-slider a'
        print(safe_get_link_content(soup, css))
        # thumb_url = soup.select(web_config.thumb_url_css)[0]['href']
        thumb_url = safe_get_link_content(soup, web_config.thumb_url_css)
        web_id = re.search(web_config.web_id_pattern, url).group(1)
        print('{}\n{}\n{}\n{}\n{}\n{}'.format(title, upload_at, categories, cover_url, thumb_url, web_id))
    if case == 2:
        pics_cat = Category.objects.get(slug='pictures')
        pics_nrop = pics_cat.nrop.all()
        print(pics_nrop.count())
        for x in pics_nrop:
            u = x.url
            soup = BeautifulSoup(requests.get(u).text, 'lxml')
            try:
                cover_url = safe_get_link_content(soup, web_config.cover_url_img_css)
                if cover_url:
                    # x.cover_url = cover_url
                    # x.save()
                    pass
                else:
                    print(u)
            except Exception as e:
                print(u)
                print(e)

    if case == 3:
        stars = Star.objects.all()
        for s in stars:
            xs = s.nrop.all()
            for x in xs:
                if check_star_name_in_title(s, x.title):
                    print('{} - {} - {}'.format(s.name, x.title, x.url))
    if case == 4:
        # print all non-studio nrop
        xs = Nrop.objects.filter(studio__isnull=True)
        print(xs.count())

        # for x in xs:
        #     studio_name = ''
        #     r1 = re.search(r'^([\w-]+?)\s((?:E|S)?\d+)+(.+)$', x.title, re.IGNORECASE)
        #     if r1:
        #         studio_name = r1.group(1)
        #     else:
        #         r2 = re.search(r'^([\w-]+)\s.+XXX (\d+p) MP4-KTR$', x.title, re.IGNORECASE)
        #         if r2:
        #             studio_name = r2.group(1)
        #         else:
        #             pass
        #             x.delete()
        #     if studio_name:
        #         studio_search = Studio.objects.filter(name__iexact=studio_name)
        #         if studio_search:
        #             studio = studio_search[0]
        #         else:  # save new studio
        #             studio = Studio(name=studio_name,
        #                             slug=slugify(studio_name))
        #             studio.save()
        #         x.studio = studio
        #         x.save()
    if case == 5:
        xs = Nrop.objects.all()
        print(xs.count())
        i = 0
        f = open('test-format.txt', 'w+')
        for x in xs:
            if re.search(r'^([\w-]+)\s.+XXX ([\w -]+?\s)?((?:(?:\d+(?:p|i)\s)?(?:MP4|WMV|x264))|(?:iMAGESET))-(\w+)$', x.title, re.IGNORECASE):
                i += 1
            else:
                f.write(x.title + '\n')
        print(i)
        f.close()
    if case == 6:
        xs = Nrop.objects.all()
        for x in xs:
            saved_title = '.'.join(x.saved_title.split(' '))
            x.saved_title = saved_title
            x.save()
