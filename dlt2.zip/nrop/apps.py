from django.apps import AppConfig


class NropConfig(AppConfig):
    name = 'nrop'
