from rest_framework import serializers
from .models import Nrop, Star
from datetime import datetime, timedelta
from django.utils import timezone


class NropSerializer(serializers.ModelSerializer):
    class Meta:
        model = Nrop
        fields = ['id', 'title', 'url']


class StarSerializer(serializers.ModelSerializer):
    days = serializers.SerializerMethodField('count_days')

    def count_days(self, obj):
        return (timezone.now() - obj.last_update).days if obj.last_update else ''

    class Meta:
        model = Star
        fields = '__all__'
        # fields = ['id', 'title', 'url']
