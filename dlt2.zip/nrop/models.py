from django.db import models
from django.utils import timezone

# Create your models here.


class BaseModel(models.Model):
    created_at = models.DateTimeField(auto_now_add=True, null=True)
    updated_at = models.DateTimeField(auto_now=True, null=True)

    class Meta:
        abstract = True


class WebConfig(BaseModel):
    base_url = models.CharField(max_length=255)
    search_url = models.CharField(max_length=255, null=True)
    result_list_css = models.CharField(max_length=255, null=True)
    result_url_css = models.CharField(max_length=255, null=True)
    next_page_css = models.CharField(max_length=255, null=True)
    title_css = models.CharField(max_length=255, null=True)
    upload_at_css = models.CharField(max_length=255, null=True)
    category_css = models.CharField(max_length=255, null=True)
    cover_url_css = models.CharField(max_length=255, null=True)
    cover_url_img_css = models.CharField(max_length=255, null=True)
    thumb_url_css = models.CharField(max_length=255, null=True)
    stream_480_css = models.CharField(max_length=255, null=True)
    stream_720_css = models.CharField(max_length=255, null=True)
    stream_1080_css = models.CharField(max_length=255, null=True)
    web_id_pattern = models.CharField(max_length=255, null=True)
    title_regex = models.CharField(max_length=255, null=True)
    title_regex_2 = models.CharField(max_length=255, null=True)
    title_regex_3 = models.CharField(max_length=255, null=True)


class Category(BaseModel):
    name = models.CharField(max_length=255, unique=True)
    slug = models.CharField(max_length=255, null=True)

    def __str__(self):
        return self.name

    class Meta:
        ordering = ['name']


class Star(BaseModel):
    name = models.CharField(max_length=255)
    other_name = models.CharField(max_length=255, null=True, blank=True)
    slug = models.CharField(max_length=255)
    except_str = models.CharField(max_length=255, null=True, blank=True)
    last_update = models.DateTimeField(null=True)
    rating = models.SmallIntegerField(null=True, blank=True)

    def __str__(self):
        return self.name

    def count_d(self):
        return (timezone.now() - self.last_update).days if self.last_update else ''


class Studio(BaseModel):
    name = models.CharField(max_length=255)
    slug = models.CharField(max_length=255, null=True)

    def __str__(self):
        return self.name


class Nrop(BaseModel):
    url = models.CharField(max_length=512)
    web_nrop_id = models.CharField(max_length=128, null=True, blank=True)
    title = models.CharField(max_length=512)
    saved_title = models.CharField(max_length=512, null=True, blank=True)
    upload_at = models.DateField(null=True)
    release_date = models.DateField(null=True)
    categories = models.ManyToManyField(Category, related_name='nrop')
    stars = models.ManyToManyField(Star, related_name='nrop')
    studio = models.ForeignKey(Studio, on_delete=models.CASCADE, related_name='nrop', null=True)
    cover_url = models.CharField(max_length=512, null=True, blank=True)
    cover_path = models.CharField(max_length=512, null=True, blank=True)
    thumb_url = models.CharField(max_length=512, null=True, blank=True)
    download_status = models.SmallIntegerField(default=0)  # 0: not yet downloaded, 1: has downloaded, 2: cannot down

    def __str__(self):
        return self.title

    class Meta:
        ordering = ['-release_date']


class DownloadUrl(BaseModel):
    nrop = models.ForeignKey(Nrop, on_delete=models.CASCADE, related_name='download_url')
    url = models.CharField(max_length=512)
    live_status = models.SmallIntegerField(default=2)  # 0: die, 1: live, 2: unknown

