import os
import logging
import logging.handlers
from django.conf import settings

x_crawl_log = os.path.join(settings.BASE_DIR, 'nrop', 'logs', 'crawl.log')
if not os.path.exists(x_crawl_log):
    f = open(x_crawl_log, 'w+')
    f.close()


class XLog:
    def __init__(self, name):
        handler = logging.handlers.WatchedFileHandler(x_crawl_log, mode='a')
        handler.setFormatter(logging.Formatter(u'%(asctime)s - %(name)s - %(message)s'))
        self.logger = logging.getLogger(name)
        self.logger.setLevel(logging.INFO)
        self.logger.addHandler(handler)
