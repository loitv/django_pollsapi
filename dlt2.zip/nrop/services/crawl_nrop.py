import re
import time
import os
import shutil
import random
import requests

from datetime import datetime
from bs4 import BeautifulSoup
from urllib.request import urlopen
from urllib.parse import urlparse

from django.template.defaultfilters import slugify
from django.conf import settings

from nrop.models import *
from nrop.services.x_log import XLog


log = XLog('CRAWL').logger
count = 0
x_cover_base_path = '/static/images/x/cover/{}_{}'


def safe_get(page_obj, selector):
    child_obj = page_obj.select(selector)
    if child_obj:
        return child_obj[0].get_text().strip()
    return None


def safe_get_link_content(page_obj, selector):
    child_obj = page_obj.select(selector)
    if child_obj:
        return child_obj[0]['href']
    return None


def pretty_instance(my_instance):
    log.info(my_instance.__class__.__name__)
    for key, value in my_instance.__dict__.items():
        if value:
            log.info('\t{:<20}{:<30}'.format(key, str(value)))
    log.info('------------------------------------------------------------------')


def check_star_name_in_title(star, title):
    names = [star.name]
    if star.other_name:
        names.extend(star.other_name.split(','))
    r = re.search(r'^(?:.+[^a-zA-Z0-9])?(' + '|'.join(names) + r')(?:[^a-zA-Z0-9].+)?$', title, re.IGNORECASE)
    if r:
        return r.group(1)
    return False


def check_title_format(web_config, title):
    r1 = re.search(web_config.title_regex, title, re.I)
    if not r1:
        r2 = re.search(web_config.title_regex_2, title, re.I)
        if not r2:
            r3 = re.search(web_config.title_regex_3, title, re.I)
            if not r3:
                return False
    return True


def get_title_info(web_config, title, upload_date):
    title_regex = re.search(web_config.title_regex, title, re.I)
    if title_regex:
        studio_name = title_regex.group(1)
        temp_date = title_regex.group(2)
        if re.search(r'^\d\d\s.+$', temp_date):
            temp_date = '20' + temp_date
        release_date = datetime.strptime(temp_date, '%Y %m %d')
        saved_title = '{} {} {}'.format(release_date.strftime('%y%m%d'), studio_name, title_regex.group(3))
    else:  # try with title_regex_2
        r2 = re.search(web_config.title_regex_2, title, re.I)
        if r2:
            studio_name = r2.group(1)
            release_date = upload_date
            saved_title = '{} {}'.format(release_date.strftime('%y%m%d'), title)
        else:  # try with title_regex_3
            r3 = re.search(web_config.title_regex_3, title, re.I)
            if r3:
                studio_name = r3.group(1)
                release_date = upload_date
                saved_title = '{} {}'.format(release_date.strftime('%y%m%d'), title)
            else:
                return None
    saved_title = '.'.join(saved_title.split(' '))
    return studio_name, release_date, saved_title


def crawl_by_search_star_name(web_config, star, is_write_file=False, is_save_to_db=False, delay=0):
    key_list = [star.name]
    new_record = 0
    if star.other_name:
        for o_name in star.other_name.split(','):
            if star.name.lower() not in o_name.lower():
                key_list.append(o_name)
    log.info(key_list)
    url_list = []
    title_list = []
    i = 0
    for keyword in key_list:
        except_list = ['GNDBondage', 'FutileStruggles']
        if star.except_str:
            except_list.extend(star.except_str.split(','))
        search_url = web_config.search_url + keyword
        log.info(search_url)
        soup = BeautifulSoup(requests.get(search_url).text, 'lxml')
        result_list = soup.select(web_config.result_list_css)
        if result_list:
            next_page = soup.select(web_config.next_page_css)
            while next_page:
                next_page_url = next_page[0]['href']
                log.info(next_page_url)
                next_page_soup = BeautifulSoup(requests.get(next_page_url).text, 'lxml')
                result_list.extend(next_page_soup.select(web_config.result_list_css))
                next_page = next_page_soup.select(web_config.next_page_css)
            for result in result_list:
                temp_title = safe_get(result, web_config.result_url_css)

                # remove record that contains any string in except list
                check = True
                for except_str in except_list:
                    if except_str.lower() in temp_title.lower():
                        log.info('EXCEPT: Strings: {} - [{}]'.format(except_str, temp_title))
                        check = False
                        break
                if not check:
                    continue

                # remove record that not contains any keyword in keys list
                if not check_star_name_in_title(star, temp_title):
                    log.info('EXCEPT: NOT contains key: {}'.format(temp_title))
                    continue

                # check for correct title format
                if not check_title_format(web_config, temp_title):
                    continue

                title_list.append(temp_title)
                result_url = safe_get_link_content(result, web_config.result_url_css)
                url_list.append(result_url)
                i += 1
    log.info('FOUND: {} results'.format(i))
    if is_save_to_db and url_list:
        new_record = save_to_db(url_list, web_config, star, delay)
    if is_write_file and title_list:
        write_result_to_text(title_list, star)
    return new_record


def write_result_to_text(title_list, star):
    file = open(os.path.join(settings.BASE_DIR, 'nrop', 'stars', star.name + '.txt'), 'w+')
    for title in title_list:
        file.write(title + '\n')


def save_to_db(url_list, web_config, star, delay):
    global count
    count = 0
    other_stars = Star.objects.exclude(id=star.id)
    other_stars_dict = get_name_dict(other_stars)

    for url in url_list:
        web_id = re.search(web_config.web_id_pattern, url).group(1)
        search_nrop = Nrop.objects.filter(web_nrop_id=web_id)
        if not search_nrop:
            log.info('Checking url: {}'.format(url))
            count += 1
            soup = BeautifulSoup(requests.get(url).text, 'lxml')
            upload_at = safe_get(soup, web_config.upload_at_css)
            if upload_at:
                upload_at = datetime.strptime(upload_at, '%B %d, %Y')
            else:
                upload_at = datetime.now()
                log.info('>>>>>>>>>>CHECK THIS CASE - {}'.format(url))
            title = safe_get(soup, web_config.title_css)
            studio_name, release_date, saved_title = get_title_info(web_config, title, upload_at)
            studio_search = Studio.objects.filter(name__iexact=studio_name)
            if studio_search:
                studio = studio_search[0]
            else:  # save new studio
                studio = Studio(name=studio_name,
                                slug=slugify(studio_name))
                studio.save()
            cats = []
            cats_lower_name = []
            categories = soup.select(web_config.category_css)
            if categories:
                for cat in categories:
                    cat = cat.get_text()
                    cats_lower_name.append(cat.lower())
                    cat_search = Category.objects.filter(name__iexact=cat)
                    if cat_search:
                        cats.append(cat_search[0])
                    else:
                        category = Category(name=cat, slug=slugify(cat))
                        category.save()
                        cats.append(category)
            if 'pictures' in cats_lower_name:
                cover_url = safe_get_link_content(soup, web_config.cover_url_img_css)
            else:
                cover_url = safe_get_link_content(soup, web_config.cover_url_css)
            thumb_url = safe_get_link_content(soup, web_config.thumb_url_css)

            nrop = Nrop(
                url=url,
                web_nrop_id=web_id,
                title=title,
                saved_title=saved_title,
                upload_at=upload_at,
                release_date=release_date,
                studio=studio,
                cover_url=cover_url,
                thumb_url=thumb_url
            )
            nrop.save()
            nrop.stars.add(star)
            if cats:
                nrop.categories.add(*cats)

            # check if other stars in new nrops
            for key, value in other_stars_dict.items():
                for name in value:
                    if name in nrop.title.lower():
                        log.info('Star {}----X: {}'.format(name, nrop.title))
                        nrop.stars.add(Star.objects.get(id=key))
            pretty_instance(nrop)
            time.sleep(delay)
    log.info('TOTAL NEW RECORD: {}'.format(count))
    return count


def add_new_star(name):
    star = Star.objects.filter(slug__exact=slugify(name))
    if not star:
        star = Star(name=name.title(), slug=slugify(name))
        star.save()

        # check if new star in existed nrops
        nrop_list = Nrop.objects.all()
        for nrop in nrop_list:
            if check_star_name_in_title(star, nrop.title):
                log.info(nrop.title)
                nrop.stars.add(star)

        web_config = WebConfig.objects.all()[0]
        crawl_by_search_star_name(web_config, star, True, True, 0)

        return star


def update_star_x_data():
    global count
    count = 0
    start_time = time.time()
    log.info('----------------------------------------------------------')
    log.info('---------------------UPDATING X STARS---------------------')
    log.info('----------------------------------------------------------\n')

    web_config = WebConfig.objects.all()[0]
    stars = Star.objects.all()

    # crawl newest data
    for star in stars:
        log.info('Crawling {}...........\n'.format(star.name.upper()))
        crawl_by_search_star_name(web_config, star, True, True, 0)
        log.info('')

    # scan titles
    # scan_titles()

    log.info('-------------------------END CRAWLING----------------------\n')
    log.info('TOTAL NEW RECORD: {}'.format(count))
    log.info('TOTAL TIME: {} s'.format(time.time() - start_time))
    log.info('-----------------------------------------------------------\n')


def scan_titles():
    log.info('---------------------SCAN TITLES---------------------')
    stars = Star.objects.all()
    names_dict = get_name_dict(stars)
    all_x_s = Nrop.objects.all().only('title')
    for x in all_x_s:
        star_id_list = x.stars.values_list('id', flat=True)
        for key, value in names_dict.items():
            if key not in star_id_list:
                for name in value:
                    if name in x.title.lower():
                        log.info('Star {}----X: {}'.format(key, x.title))
                        x.stars.add(Star.objects.get(id=key))
    log.info('-----------------------------------------------------\n')


def single_scan_titles(star, other_stars_dict, nrop):
    stars = Star.objects.exclude(id=star.id)
    names_dict = get_name_dict(stars)
    s_nrops = star.nrop.all().only('title')
    for x in s_nrops:
        for key, value in names_dict.items():
            for name in value:
                if name in x.title.lower():
                    log.info('Star {}----X: {}'.format(key, x.title))
                    x.stars.add(Star.objects.get(id=key))


def get_name_dict(stars):
    names_dict = {}
    for star in stars:
        name_keys = [star.name.lower()]
        other_names = star.other_name
        if other_names:
            other_names = other_names.split(',')
            for o_name in other_names:
                if star.name.lower() not in o_name.lower():
                    name_keys.append(o_name.lower())
        names_dict[star.id] = name_keys
    return names_dict


def update_nrop_cover_path(nrop, status):
    nrop.cover_path = status
    nrop.save()


def pre_download_image(n):
    base_path = os.path.join(settings.BASE_DIR, 'static', 'images', 'x', 'cover')
    img_search = re.search(settings.IMG_URL_PATTERN, n.cover_url, re.IGNORECASE)
    if img_search:
        img_name = img_search.group(1)
        save_path = os.path.join(base_path, '{}_{}'.format(n.web_nrop_id, img_name))
        r = requests.get(n.cover_url)
        soup = BeautifulSoup(r.text, 'lxml')
        download_image(n, soup, n.cover_url, save_path, img_name)
    else:
        n.cover_path = 'false:cannot get image name from url'
        n.save()


def download_image(nrop, soup, img_url, save_path, img_name):
    hosts_img_selector = {'imagetwist': ['a.btn.btn-success.btn-lg', 'href'],
                          'pixhost': ['img#image', 'src'],
                          'imgspice': ['img#imgpreview', 'src']}
    if all(key not in img_url for key in hosts_img_selector.keys()):
        update_nrop_cover_path(nrop, 'false:host is not supported')
    else:
        for host, x_path in hosts_img_selector.items():
            if host in img_url:
                link = soup.select(x_path[0])
                if link:
                    direct_link = link[0][x_path[1]]
                    print('Downloading...| {}'.format(direct_link))
                    response = requests.get(direct_link, stream=True)
                    with open(save_path, 'wb') as out_file:
                        shutil.copyfileobj(response.raw, out_file)
                    update_nrop_cover_path(nrop, 'ok:{}'.format(x_cover_base_path.format(nrop.web_nrop_id, img_name)))
                else:
                    update_nrop_cover_path(nrop, 'false:cannot get direct link download')
                    print('cannot get direct link download')
                break
    pass


def crawl_img_cover(number_of_download):
    nrops = Nrop.objects.filter(cover_url__isnull=False, cover_path__isnull=True)
    if nrops.count() > 0:
        if nrops.count() > number_of_download:
            nrops = nrops[0:number_of_download]
        for n in nrops:
            pre_download_image(n)

