from django.core.management.base import BaseCommand, CommandError
from nrop.models import WebConfig, Star
from nrop.services.crawl_nrop import crawl_by_search_star_name, add_new_star, scan_titles,\
    update_star_x_data, crawl_img_cover
from nrop.tests import test_2, test


class Command(BaseCommand):
    def add_arguments(self, parser):
        parser.add_argument(
            'opt', nargs='+', type=str
        )

    def handle(self, *args, **options):
        if len(options['opt']) == 1:
            if 'scan_titles' in options['opt']:
                scan_titles()
            elif 'update_stars' in options['opt']:
                update_star_x_data()
                pass
            self.stdout.write(self.style.SUCCESS('Successful'))
        elif len(options['opt']) == 2:
            if options['opt'][0] == 'crawl':
                keyword = options['opt'][1]
                keyword = ''.join(' ' if c in ['-', '_'] else c for c in keyword)
                web_config = WebConfig.objects.all()[0]
                star = Star.objects.filter(name__iexact=keyword)[0]
                crawl_by_search_star_name(web_config, star)
                self.stdout.write(self.style.SUCCESS('Successful'))
            elif options['opt'][0] == 'add_star':
                star_name = options['opt'][1]
                star_name = ''.join(' ' if c in ['-', '_'] else c for c in star_name)
                add_new_star(star_name)
            elif options['opt'][0] == 'crawl_image':
                number_of_download = int(options['opt'][1])
                crawl_img_cover(number_of_download)
            elif options['opt'][0] == 'test_soup':
                case = int(options['opt'][1])
                test(case)
            else:
                raise CommandError('No command found!')
        elif len(options['opt']) == 5:
            if options['opt'][0] == 'crawl':
                keyword = options['opt'][1]
                is_write_file = True if options['opt'][2].lower() in ['y', 'yes'] else False
                is_save_db = True if options['opt'][3].lower() in ['y', 'yes'] else False
                delay = int(options['opt'][4])
                keyword = ''.join(' ' if c in ['-', '_'] else c for c in keyword)
                star = Star.objects.filter(name__iexact=keyword)[0]
                web_config = WebConfig.objects.all()[0]
                crawl_by_search_star_name(web_config, star, is_write_file, is_save_db, delay)
                self.stdout.write(self.style.SUCCESS('Successful'))
            else:
                raise CommandError('No command found!')
        else:
            raise CommandError('Error!')

