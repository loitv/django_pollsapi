from django.contrib import admin
from .models import *

# Register your models here.


@admin.register(WebConfig)
class WebConfigAdmin(admin.ModelAdmin):
    list_display = ('base_url', 'search_url', 'result_list_css', 'result_url_css', 'result_list_css', 'next_page_css',)


@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ('name', 'slug',)


@admin.register(Star)
class StarAdmin(admin.ModelAdmin):
    list_display = ('name', 'other_name', 'slug', 'list_nrop')
    list_filter = ('name',)

    @staticmethod
    def list_nrop(obj):
        return "\n".join([n.title[:50] for n in obj.nrop.all()[0:5]])


# url = models.CharField(max_length=512)
#     web_nrop_id = models.CharField(max_length=128, null=True, blank=True)
#     title = models.CharField(max_length=512)
#     saved_title = models.CharField(max_length=512, null=True, blank=True)
#     upload_at = models.DateField(null=True)
#     release_date = models.DateField(null=True)
#     categories = models.ManyToManyField(Category, related_name='nrop')
#     stars = models.ManyToManyField(Star, related_name='nrop')
#     studio = models.ForeignKey(Studio, on_delete=models.CASCADE, related_name='nrop', null=True)
#     cover_url = models.CharField(max_length=512, null=True, blank=True)
#     cover_path = models.CharField(max_length=512, null=True, blank=True)
#     thumb_url = models.CharField(max_length=512, null=True, blank=True)
#     download_status = models.SmallIntegerField(default=0)  # 0: not yet downloaded, 1: has downloaded, 2: cannot down

@admin.register(Nrop)
class NropAdmin(admin.ModelAdmin):
    list_display = ('id', 'url', 'title', 'saved_title', 'get_stars', 'upload_at', 'cover_url', 'thumb_url', 'download_status',)
    list_filter = ('studio',)
    search_fields = ('title',)
    date_hierarchy = 'release_date'
    ordering = ('title', 'stars')

    @staticmethod
    def get_stars(obj):
        return "\n".join([star.name for star in obj.stars.all()])


