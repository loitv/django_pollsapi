from django.db import models

# Create your models here.


class BaseModel(models.Model):
    created_at = models.DateTimeField(auto_now_add=True, null=True)
    updated_at = models.DateTimeField(auto_now=True, null=True)
    
    class Meta:
        abstract = True


class Author(BaseModel):
    code = models.CharField(max_length=255, unique=True)
    name = models.CharField(max_length=255)
    country = models.CharField(max_length=255)
    avatar = models.ImageField(null=True, upload_to='avatar')


class Manga(BaseModel):
    name = models.CharField(max_length=512)
    slug = models.SlugField(max_length=512)
    author = models.ForeignKey(Author, on_delete=models.CASCADE, related_name='manga', null=True)
    content = models.TextField(null=True)
    cover = models.ImageField(null=True, upload_to='cover')


class Chapter(BaseModel):
    number = models.SmallIntegerField()
    title = models.CharField(max_length=512, null=True)
    manga = models.ForeignKey(Manga, on_delete=models.CASCADE, related_name='chaps')


class Page(BaseModel):
    number = models.SmallIntegerField()
    chapter = models.ForeignKey(Chapter, on_delete=models.CASCADE, related_name='pages')
    image = models.ImageField(null=True, upload_to='manga/%Y/%m/%d')


# def get_upload_path(page):
#     manga = page.chapter.manga
#     manga_name = manga.name
#     if len(manga_name) > 20:
#         manga_name = manga_name[:20]
#     manga_name = '_'.join(manga_name.split(' '))
#     manga_name += '_' + str(manga.id)
#     chapter_number = str(page.chapter.number)
    
#     return 'manga/{}/{}'.format(manga_name, chapter_number)
