from django.apps import AppConfig


class MangaConfig(AppConfig):
    name = 'manga'
