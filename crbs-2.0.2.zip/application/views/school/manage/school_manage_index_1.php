
<h5>
	<a href="<?php echo site_url('school/details') ?>">
		<img src="webroot/images/ui/school_manage_details.png" hspace="4" align="top" width="16" height="16" />
		School details
	</a>
</h5>

<h5>
	<a href="<?php echo site_url('users') ?>">
		<img src="webroot/images/ui/school_manage_users.png" hspace="4" align="top" width="16" height="16" />
		Manage users
	</a>
</h5>

<h5>
	<a href="<?php echo site_url('periods') ?>">
		<img src="webroot/images/ui/school_manage_times.png" hspace="4" align="top" width="16" height="16" />
		The School Day
	</a>
</h5>

<h5>
	<a href="<?php echo site_url('weeks') ?>">
		<img src="webroot/images/ui/school_manage_weeks.png" hspace="4" align="top" width="16" height="16" />
		Week Cycle
	</a>
</h5>

<h5>
	<a href="<?php echo site_url('holidays') ?>">
		<img src="webroot/images/ui/school_manage_holidays.png" hspace="4" align="top" width="16" height="16" />
		Holidays
	</a>
</h5>

<!-- <h5>
	<a href="<?php echo site_url('timetable') ?>">
		<img src="webroot/images/ui/school_manage_timetable.png" hspace="4" align="top" width="16" height="16" />
		School timetable
	</a>
</h5> -->


