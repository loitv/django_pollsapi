<table width="100%" cellpadding="4" cellspacing="0">
<tr>
<td width="50%" align="left"><?php echo $date ?></td>
<td width="50%" align="right"><?php echo $room ?></td>
</tr>
</table>