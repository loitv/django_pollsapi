<table border="0" cellpadding="4" cellspacing="4" class="bookings" align="center" style="border:1px solid #000;border-width:0px 0px;margin:16px auto;">
<tr>
<td width="25%" align="right" valign="middle"><strong>Legend:</strong></td>
<td class="free" width="25%" align="center">Free period</td>
<td class="static" width="25%" align="center">Timetabled lesson</td>
<td class="staff" width="25%" align="center">Staff booking</td>
</tr></table>
