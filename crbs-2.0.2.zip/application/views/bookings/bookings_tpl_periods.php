<table border="1" cellpadding="5" cellspacing="2" bordercolor="#ffffff">

<tr>
	<td>X</td>
	{periods}
		<td>
			{name}<br />
			{id}
		</td>
	{/periods}
</tr>

{rooms}
	<tr>
		<td>
			{name}
		</td>
	</tr>
{/rooms}

</table>
