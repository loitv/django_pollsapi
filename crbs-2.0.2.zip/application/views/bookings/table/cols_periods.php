<td align="center" width="<?php echo $width ?>">
	<strong><?php echo html_escape($name) ?></strong><br />
	<span style="font-size:90%">
		<?php echo date('g:i', strtotime($time_start)).'-'.date('g:i', strtotime($time_end)) ?>
	</span>
</td>
