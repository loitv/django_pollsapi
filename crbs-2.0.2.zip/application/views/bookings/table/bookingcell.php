<td class="<?php echo $class ?>" align="center" valign="middle" width="<?php echo $width ?>" style="overflow:hidden">
<div width="100%" style="overflow:hidden"><?php echo $body ?></div>
</td>