<td align="right" width="<?php echo $width ?>" style="padding: 15px 5px;">
	<strong><?php echo html_escape($name) ?></strong>
	<br />
	<span style="font-size:90%"><?= date('jS M', strtotime($date)) ?></span>
</td>
