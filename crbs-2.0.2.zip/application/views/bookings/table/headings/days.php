<td align="center" width="<?php echo $width ?>">
	<strong><?php echo html_escape($name) ?></strong><br /><br />
</td>
