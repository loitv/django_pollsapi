<p class="msgbox error"><?php echo $content; ?></p>
