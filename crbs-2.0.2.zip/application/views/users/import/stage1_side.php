<style>
pre {
	background: #f4f4f4;
	padding: 10px;
}
</style>

<div>
	<h5>CSV format</h5>
	<p>Your CSV file should be in this format:</p>
	<pre><code>username, firstname, lastname, email, password</code></pre>
	<p>It doesn't matter if it contains the header row.</p>
	<p>Any usernames that already exist will be ignored.</p>
</div>
<br>
