<dl>
  <dt>School Holidays</dt>
  <dd>The dates should be the first and last dates of the <span>holiday</span> itself, do not include the teaching days.</dd>
  <dt>Date format</dt>
  <dd>Use the <span>DD/MM/YYYY</span> format when entering dates, for example <strong>16/04/2018</strong></dd>
</dl>
