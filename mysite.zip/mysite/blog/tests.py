from django.test import TestCase

# Create your tests here.

params = "cBox=&isDeleteY=&pageIndex=1&pageUnit=10&orderBy=&orderByType=&menuGubun=&paramGubun=&frmSearchFilterYn=N" \
         "&checkJobTokenType=file&checkJobToken=6556124413713&paramGubunEx=N&projectModelType=ETC&displayType=BADUK" \
         "&workType=DETECTION&objectId=00L7B9PFStPMWL1000&projectId=00L7B9PFStPMWL1000&deptId=&deptName=&displayDept" \
         "=&importance=&status=&openSubStatus=&testPlanId=00L7B9PFXtPMWL1000&occurPhase=&occurType=&occurTypeIsNull" \
         "=&swVersion=&functionBlock=&functionBlockIsNull=&detailCategory=&detailCategoryfrm=&afterMgmtYn" \
         "=&afterStatus=&searchDefectType=&searchDefectCategory=&defectType=&defectCategory=&defectCategoryStr" \
         "=&testUnit=&testItemId=&testItemIdIsNull=&swResolveType=&hwVersion=&hwVerIsNull=&userId=&defaultDefectId" \
         "=&popup=N&isPopUp=N&callType=&nisPartGroup=&nisPartCode=&nisPartVendor=&nisTestGubun=&defectSelectable=Y" \
         "&testTypeSqlStr=&selectRowId=&statusStr=&createUser=P170113005329C104884&periodType=&period=&isSwDefect" \
         "=&addOption=&regDate=&ddTestType=&mainInChargeUserId=&mainInChargeUserIds=&frmDefectStat=&mainInChargeYn" \
         "=&subInChargeUserId=&changeId=&isDevVerify=&frmDetailYn=N&excelMaxCount=50000&sliceUnit=10000" \
         "&pjtProjectClass=&tqmDefectRange=&defectCode=&devModelName=&mfgModelCode=&maintItemName=&title=&projectName" \
         "=&regStartDate=&regEndDate=&createStartDate=&createEndDate=&resolveStartDate=&resolveEndDate" \
         "=&closeStartDate=&closeEndDate=&rejStartDate=&rejEndDate=&resStartDate=&resEndDate=&createUserName" \
         "=&createUserIds=&createUserId=&inChargeUserName=&inChargeUserIds=&inChargeUserId=&resolveUserName" \
         "=&resolveUserIds=&resolveUserId=&hierarchySearchDeptYn=&occurRateType=&occurLanguage=&reqVer=&swResolveVer" \
         "=&checksum=&swCloseVer=&cqId=&testCaseId=&testCaseYn=&searchContent=&searchReason=&searchCountermeasure" \
         "=&detailProblemType=&detailProblemTypeName=&solPg=&solPgName=&prodCategory=&prodCategoryName=&overlapCheck" \
         "=&sideEffectYn=&failCaseYn=&failureType=&failureTypes=&partCode=&commonManage=&commonCategory" \
         "=&categoryDetail=&projectNameStr=&projectStatus=&frmTgStatus=N&tgUserId=&pjtObjectId=&hwVer=&rejectYn" \
         "=&tqmAuthYn=N&mktProjectId=&modelGroupYn=&deptCode=&tgLevel1=&tgLevel2=&delayPeriod=&resolveUnopen" \
         "=&notExcel=N&deptType=&searchFilter1AllChecked=N&searchFilter2AllChecked=N&searchFilter3AllChecked=N" \
         "&searchFilter4AllChecked=N&searchFilter5AllChecked=N&searchFilter6AllChecked=N&searchFilter6_2AllChecked=N" \
         "&searchFilter7AllChecked=N&searchFilter8AllChecked=N&searchFilter9AllChecked=N&searchFilter17AllChecked=N" \
         "&searchFilter18AllChecked=N&searchFilter19AllChecked=&refObjectIdPbs=&refObjectIdDev=&refObjectIdMfg" \
         "=&refObjectIdMaint=&refObjectIdEtc=&refObjectIdComp=&objectType=ETC&classification=&testUnitSw" \
         "=005YBJ0I1tPMWL1000%2C00KD3GH4TtPMWL1000%2C00ASOPQ0ZtPMWL1000%2C00036UZ8QtPMWL0000&reviewDept=&reviewerName" \
         "=&reviewerIds=&reviewResult=&verifyUser=&nextClReleaseYn=&searchType=&category=&tempEtc1=&swVersionSel" \
         "=&defectId=&allInChargeUserName=&allInChargeUserIds=&createUserVendorName=&createUserVendorIds" \
         "=&inChargeUserVendorName=&inChargeUserVendorIds=&resolveUserVendorName=&resolveUserVendorIds=&regDeptCode" \
         "=&solDeptCode=&ccListName=&ccListIds=&defectSearchType=&resolveStatusIds=&resolveStatus2Ids=&tgCategory1" \
         "=&tgCategory2Ids=&statusIds=&tag=&comment=&logComment=&occurPhaseIds=&testCategoryIds=&testItemIds" \
         "=&functionBlockIds=&detailFunctionIds=&importanceIds=&salesRegionIds=&reviewResultIds=&tgEmpty" \
         "=&swVersionSubmitYn=&opVersionInfoId=&swVersionName=&searchUserType=&delayReleasePeriodFrom" \
         "=&delayReleasePeriodTo=&ddReqReason=MR_ISSUE&resourceCode=&testItemName=&modelNumber=&osVersion=&nation" \
         "=&isCommentExcel=N&deletedDefectYn=&convergenceYn=&convergenceDetail=&confirmStatus=&ownerTg=&ownerTgName" \
         "=&relatedLayer=&transferType=&cloneType=&cloneDivision=&compPartCode=&compDesignVer=&compRecipeVer=&mainYn" \
         "=mainN&iotDashboardYn=&gubun=&regDivision=&resolveDivision=&regWeekNumber=&targetYear=&listOrder" \
         "=*&searchOption=TITLE&searchText=&pageSize=10&defectTypeVO.inChargeUserArr0=P180104051328C103893" \
         "&defectTypeVO.inChargeUserArr0=P181102022916C102495&defectTypeVO.inChargeUserArr0=P181102022916C102507&tNum" \
         "=0&cNum=0&defectHistorySearchVO.isComment=Y&defectHistorySearchVO.isUser=Y&defectHistorySearchVO.isRes=Y" \
         "&defectHistorySearchVO.isRej=Y&defectVO.comment=&changeSizeComment=1&defectTypeVO.inChargeUserArr1" \
         "=D130829101912C100464&defectTypeVO.inChargeUserArr1=P181102022916C102470&defectTypeVO.inChargeUserArr1" \
         "=P180703055434C102282&tNum=0&cNum=0&defectHistorySearchVO.isComment=Y&defectHistorySearchVO.isUser=Y" \
         "&defectHistorySearchVO.isRes=Y&defectHistorySearchVO.isRej=Y&defectVO.comment=&changeSizeComment=1" \
         "&defectTypeVO.inChargeUserArr2=P181102022916C102478&defectTypeVO.inChargeUserArr2=P170801051419C100712&tNum" \
         "=0&cNum=0&defectHistorySearchVO.isComment=Y&defectHistorySearchVO.isUser=Y&defectHistorySearchVO.isRes=Y" \
         "&defectHistorySearchVO.isRej=Y&defectVO.comment=&changeSizeComment=1&defectTypeVO.inChargeUserArr3" \
         "=P180703055434C102275&tNum=0&cNum=0&defectHistorySearchVO.isComment=Y&defectHistorySearchVO.isUser=Y" \
         "&defectHistorySearchVO.isRes=Y&defectHistorySearchVO.isRej=Y&defectVO.comment=&changeSizeComment=1" \
         "&defectTypeVO.inChargeUserArr4=P180703055434C102275&tNum=0&cNum=0&defectHistorySearchVO.isComment=Y" \
         "&defectHistorySearchVO.isUser=Y&defectHistorySearchVO.isRes=Y&defectHistorySearchVO.isRej=Y&defectVO" \
         ".comment=&changeSizeComment=1&defectTypeVO.inChargeUserArr5=P180703055434C102275&tNum=0&cNum=0" \
         "&defectHistorySearchVO.isComment=Y&defectHistorySearchVO.isUser=Y&defectHistorySearchVO.isRes=Y" \
         "&defectHistorySearchVO.isRej=Y&defectVO.comment=&changeSizeComment=1&defectTypeVO.inChargeUserArr6" \
         "=D130829101912C100464&tNum=0&cNum=0&defectHistorySearchVO.isComment=Y&defectHistorySearchVO.isUser=Y" \
         "&defectHistorySearchVO.isRes=Y&defectHistorySearchVO.isRej=Y&defectVO.comment=&changeSizeComment=1" \
         "&defectTypeVO.inChargeUserArr7=P181102022917C102514&defectTypeVO.inChargeUserArr7=D140709094446C101890" \
         "&defectTypeVO.inChargeUserArr7=P181102022918C102555&tNum=0&cNum=0&defectHistorySearchVO.isComment=Y" \
         "&defectHistorySearchVO.isUser=Y&defectHistorySearchVO.isRes=Y&defectHistorySearchVO.isRej=Y&defectVO" \
         ".comment=&changeSizeComment=1&defectTypeVO.inChargeUserArr8=M180524021139C103148&defectTypeVO" \
         ".inChargeUserArr8=P181204025404C102570&defectTypeVO.inChargeUserArr8=P181102022916C102489&tNum=0&cNum=0" \
         "&defectHistorySearchVO.isComment=Y&defectHistorySearchVO.isUser=Y&defectHistorySearchVO.isRes=Y" \
         "&defectHistorySearchVO.isRej=Y&defectVO.comment=&changeSizeComment=1&defectTypeVO.inChargeUserArr9" \
         "=P180703055434C102275&defectTypeVO.inChargeUserArr9=D130829101912C100464&tNum=0&cNum=0" \
         "&defectHistorySearchVO.isComment=Y&defectHistorySearchVO.isUser=Y&defectHistorySearchVO.isRes=Y" \
         "&defectHistorySearchVO.isRej=Y&defectVO.comment=&changeSizeComment=1"

# new_params = params.replace('&', '\n')
# print(new_params)

a_params = params.split('&')
new_params = []
# print(a_params)
for param in a_params:
    a_param = param.split('=')
    new_param = '\"' + a_param[0] + '\": \"' + a_param[1] + '\"'
    new_params.append(new_param)

# print(new_params)

for p in new_params:
    print(p + ',')
