from django.db import models

# Create your models here.


class Candidate(models.Model):
    a_uid = models.CharField(max_length=128)
    w = models.CharField(max_length=128, default="")
    a_idx = models.CharField(max_length=128, default="")
    sca = models.CharField(max_length=128, default="")
    sfl = models.CharField(max_length=128, default="")
    stx = models.CharField(max_length=128, default="")
    page = models.CharField(max_length=128, default="")
    tk_idx = models.CharField(max_length=128, default="13")
    a_status_old = models.CharField(max_length=128, default="")
    imgidx = models.CharField(max_length=128)
    a_level = models.CharField(max_length=16)
    t_code = models.CharField(max_length=16, default="00")
    u_email0 = models.CharField(max_length=128)
    u_email1 = models.CharField(max_length=128)
    u_pwd = models.CharField(max_length=128)
    u_pwd_confirm = models.CharField(max_length=128)
    u_surname = models.CharField(max_length=128)
    u_kname = models.CharField(max_length=128)
    u_birth0 = models.CharField(max_length=128)
    u_birth1 = models.CharField(max_length=128)
    u_birth2 = models.CharField(max_length=128)
    u_age = models.CharField(max_length=128)
    u_sex = models.CharField(max_length=128, default="m")
    u_nation = models.CharField(max_length=128, default="VNM")
    u_sid = models.CharField(max_length=128, unique=True)
    u_job = models.CharField(max_length=128, default="1")
    u_job_etc = models.CharField(max_length=255, default="")
    u_tel = models.CharField(max_length=128, default="1236547890")
    u_hp = models.CharField(max_length=128, default="1234568790")
    u_addr = models.CharField(max_length=128, default="Ha Noi")
    u_motive = models.CharField(max_length=128, default="1")
    u_motive_etc = models.CharField(max_length=128, default="")
    u_purpose = models.CharField(max_length=128, default="1")
    u_purpose_etc = models.CharField(max_length=128, default="")
    checkbox = models.CharField(max_length=128, default="on")
    checkbox2 = models.CharField(max_length=128, default="on")



