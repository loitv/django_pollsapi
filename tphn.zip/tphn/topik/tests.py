from datetime import datetime
from random import randint
import requests
from topik.models import *


def create_new():
    c = Candidate(
        a_uid=datetime.now().strftime('%Y%m%d%H%M%S00'),
        imgidx="189010",
        a_level=str(randint(7, 8)),
        u_email0="newsky1763",
        u_email1="gmail.com",
        u_pwd="@abc13579",
        u_pwd_confirm="@abc13579",
        u_surname="Tran Van Loi",
        u_kname="Tran Van Loi",
        u_birth0="1993",
        u_birth1=str(randint(1, 12)),
        u_birth2=str(randint(1, 31)),
        u_age="27",
        u_sex="m",
        u_sid="{}{}{}123{}{}{}".format(randint(1,9), randint(0,9), randint(0,9), randint(0,9), randint(0,9), randint(0,9)),
        u_job="2",
    )
    c.save()
    print(c.__dict__)


def test():
    c = Candidate.objects.filter(id=1).values()[0]
    print(c)
    r = requests.post('http://www.topikhanoi.com/bbs/apply_reg_update.php', data=c)
    print(r.text)
