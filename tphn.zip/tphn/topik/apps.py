from django.apps import AppConfig


class TopikConfig(AppConfig):
    name = 'topik'
