from django.shortcuts import render
import requests

# Create your views here.
